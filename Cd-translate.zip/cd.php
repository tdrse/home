<?php
/*
Copyright © tdrse
Version 0.3.1
Update 2022-3-21
Contact tdrse@outlook.com
*/
$get=$_GET['!'];
$don=$_GET['u'];
$adw="into";/*词条添加页关键词 Add key word*/
$default="cn";/*默认语言 Default language*/
$host="http://localhost:8088";/*主机名 Host name*/
$cdna=$_SERVER['PHP_SELF'];
$lang_cn = array (
  '0' => '系统错误',
  '1' => '成功',
  '2' => '失败',
  '3' => '没有找到词条',
  '4' => '勿岩-TDRSE',
  '5' => '搜索其实很简单...',
  '6' => '搜索',
  '7' => '词条',
  '8' => '解释 使用<br>换行',
  '9' => '更多 使用<br>换行',
  '10'=> '添加',
  '11'=> '添加词条'
);//中文
$lang_en = array (
  '0' => 'System error',
  '1' => 'OK',
  '2' => 'Failed',
  '3' => 'Not found',
  '4' => 'Norock-tdrse',
  '5' => 'Search is actually very simple...',
  '6' => 'Search',
  '7' => 'The key word',
  '8' => 'About the word,use <br> to warp',
  '9' => 'More,use <br> to warp',
  '10'=> 'Add',
  '11'=> 'Plus'
);//English
$lang_jp = array (
  '0' => 'システムエラー',
  '1' => '完成',
  '2' => '失敗',
  '3' => '項目が見つからない',
  '4' => '岩い-TDRSE',
  '5' => '検索は簡単です...',
  '6' => '検索',
  '7' => '項目',
  '8' => '説明 <br>で改行する',
  '9' => 'もっと説明 <br>で改行する',
  '10'=> '添加',
  '11'=> '添加項目'
);//日本語
$lang_ru = array (
  '0' => 'Системная ошибка',
  '1' => 'Βыполнить',
  '2' => 'Ηеудача',
  '3' => 'Не найдено',
  '4' => 'Ηеска-tdrse',
  '5' => 'Πоиск очень простой...',
  '6' => 'Πоиск',
  '7' => 'Статья',
  '8' => 'Οбъясн [используйте <br> для изменения строки]',
  '9' => 'Πояснения [используйте <br> для изменения строки]',
  '10'=> 'Добавить',
  '11'=> 'Добавить статья'
);//Русский
$lang_fr = array (
  '0' => 'Erreur système',
  '1' => 'Terminé',
  '2' => 'Échec',
  '3' => 'Non trouvé',
  '4' => 'Taenite-tdrse',
  '5' => 'La recherche est simple...',
  '6' => 'Recherche',
  '7' => 'Mot',
  '8' => 'Explication [utiliser <br> pour changer de ligne]',
  '9' => 'Plus [utiliser <br> pour changer de ligne]',
  '10'=> 'Ajouter',
  '11'=> 'Ajouter mot'
);//Le français
if($get!=="cn" && $get!=="en" && $get!=="jp" && $get!=="ru" && $get!=="fr"){echo "<script>location='?!=$default'</script>";exit;}
if($get=="en"){$lang=$lang_en;}else if($get=="cn"){$lang=$lang_cn;}else if($get=="jp"){$lang=$lang_jp;}else if($get=="ru"){$lang=$lang_ru;}else if($get=="fr"){$lang=$lang_fr;}
$dir="./db";
if(!is_dir($dir)) {
if(!mkdir($dir, 0775, true)){error($lang[0]);exit;}}
if($don==$adw){
$in=$_GET['t'];
if($in=="set"){
$ver=$_SERVER['HTTP_REFERER'];
if($ver!=="$host$cdna?!=en&u=$adw" && $ver!=="$host$cdna?!=cn&u=$adw" && $ver!=="$host$cdna?!=jp&u=$adw" && $ver!=="$host$cdna?!=ru&u=$adw" && $ver!=="$host$cdna?!=fr&u=$adw"){exit;}
$ct=$_POST['tct'];
$pre=$_POST['tpre'];
$mor=$_POST['tmor'];
$ctpd=preg_replace('# #','',$ct);
$prepd=preg_replace('# #','',$pre);
$morpd=preg_replace('# #','',$mor);
if($ctpd=="" or $prepd=="" or $morpd==""){exit;}
$ctv=addcslashes($ct,"'");
$prev=addcslashes($pre,"'");
$morv=addcslashes($mor,"'");
$one="$"."thect=";
$two="$"."thepre=";
$three="$"."themor=";
$nf="$dir/$ct.tdr.php";
$thil="<?php $one'$ctv';$two'$prev';$three'$morv';?>";
if(!file_exists($nf)){
$fp=fopen($nf,"w");
fputs($fp,$thil);
fclose($fp);
echo "<script>alert('$lang[1]',top.location='?!=$get&u=$adw')</script>";
}else{
echo "<script>alert('$lang[2]',top.location='?!=$get&u=$adw')</script>";
exit;}
}
?>
<!DOCTYPE html>
<html onselectstart="return false">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title><?php echo $lang[4];?></title>
</head>
<body style="margin:0;">
<iframe allowfullscreen="allowfullscreen" name="itd"></iframe>
<style>
*{
box-sizing:border-box;
outline:none;
color:#555;
line-height:16px;
}
iframe{
width:100%;
height:calc(100% - 148px);
position:absolute;
border:0px solid #f7f7f7;
}
input{
width:100%;
padding:5px;
border-radius:0px;
line-height:16px;
background:#fff;
border:2px solid #fff;
}
table{
width:1%;
position:absolute;
bottom:0;
padding:0;
margin:0;
background:#eee;
border:0px solid #f7f7f7;
transition:width 0.5s;
}
table:hover{
width:100%;
}
td{
margin:0;
padding:0;
}
</style>
<table>
<form action="<?php echo '?!='.$get.'&u='.$adw.'&t=set';?>" method="post" target="itd">
<tr><td style="font-size:10px;text-align:center;"><?php echo $lang[11];?></td></tr>
<tr><td><input type="text" placeholder="<?php echo $lang[7];?>" name="tct"></td></tr>
<tr><td><input type="text" placeholder="<?php echo $lang[8];?>" name="tpre"></td></tr>
<tr><td><input type="text" placeholder="<?php echo $lang[9];?>" name="tmor"></td></tr>
<tr><td><input type="submit" value="<?php echo $lang[10];?>"></td>
</tr>
</form>
</table>
</body>
</html>
<?php
exit;
}
if($don=="the"){
$the=$_POST['the'];
$dn=$_GET['t'];
if($dn){$tnl="$dir/$dn.tdr.php";}else{$tnl="$dir/$the.tdr.php";}
if(file_exists($tnl)){
require $tnl;?>
<html onselectstart="return false">
<title><?php echo $lang[4].'-'.$thect;?></title>
<style>
*{
box-sizing:border-box;
}
div{
background:#f7f7f7;
padding:10px;
color:#555;
}
.head{
font-size:24px;
font-weight:bold;
}
.more{
font-size:18px;
padding:0;
font-weight:bold;
}
</style>
<div class="head"><?php echo htmlspecialchars($thect);?></div>
<div><?php echo str_replace('&lt;br&gt;','<br>',nl2br(htmlspecialchars($thepre)));?></div>
<div><div class="more">＃</div><?php echo str_replace('&lt;br&gt;','<br>',nl2br(htmlspecialchars($themor)));?></div>
</html>
<?php
}else{?>
<html onselectstart="return false">
<title><?php echo $lang[4].'-'.$lang[3];?></title>
<style>
*{
line-height:16px;
box-sizing:border-box;
}
div{
background:#f7f7f7;
padding:10px;
color:#555;
}
</style>
<div><?php echo $lang[3];?></div>
</html>
<?php
}exit;}
?>
<!DOCTYPE html>
<html onselectstart="return false">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title><?php echo $lang[4];?></title>
</head>
<body style="margin:0;">
<iframe allowfullscreen="allowfullscreen" name="itd"></iframe>
<style>
*{
box-sizing:border-box;
outline:none;
color:#555;
line-height:16px;
}
iframe{
width:100%;
height:calc(100% - 40px);
position:absolute;
border:0px solid #f7f7f7;
}
input{
width:100%;
padding:3px;
font-size:20px;
border-radius:0px;
line-height:30px;
background:#f7f7f7;
border:0px solid #f7f7f7;
}
table{
width:100%;
position:absolute;
bottom:0;
padding:0;
margin:0;
background:#eee;
border:0px solid #f7f7f7;
}
td{
margin:0;
padding:0;
}
</style>
<div align="center">
<form action="<?php echo '?!='.$get.'&u=the';?>" method="post" target="itd">
<table>
<tr>
<td><input type="text" placeholder="<?php echo $lang[5];?>" name="the"></td>
<td><input type="submit" value="<?php echo $lang[6];?>"></td>
</tr>
</table>
</form>
</div>
</body>
</html>