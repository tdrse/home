<?php 
$lifeTime = 999 * 3600;
session_set_cookie_params($lifeTime); 
session_start();
$username = $_POST['username'];
$password = md5($_POST['password']);
$username = strip_tags($username);
$username = htmlspecialchars($username); 
$username = addslashes($username);
if ($username=="" or $password=="d41d8cd98f00b204e9800998ecf8427e" ) {
  	echo "<script>alert('账号(密码)不能为空！')</script>";
	exit;
}
$namef = "./user/$username.php";
if(!file_exists($namef)){
  echo "<script>alert('没有此用户！')</script>";
  exit;
}
require "./user/$username.php";
		if ($password=="$pw") {
			$_SESSION['tdrunofs']=$username;
			$_SESSION['tdrper']=$uid;
			echo "<script>alert('登录成功！',top.location='./')</script>";
		}else{
          	echo "<script>alert('账号或密码不正确！')</script>";
		}
?>