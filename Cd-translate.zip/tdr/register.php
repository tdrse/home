<?php  
$lifeTime = 999 * 3600;
session_set_cookie_params($lifeTime); 
session_start();
date_default_timezone_set('PRC');
$username=$_POST['username'];
$repw=$_POST['password'];
$password=md5($repw);
$day = time();
$fil="num.txt";
if($username=="" or $password=="d41d8cd98f00b204e9800998ecf8427e"){
echo "<script>alert('账号(密码)不能为空！')</script>";
exit;
}
$namef = "../user/$username.php";
if(file_exists($namef)){
  echo "<script>alert('用户已存在！',top.location='../?!=register')</script>";
  exit;
}
if(is_numeric($repw)){
  echo "<script>alert('请勿设置纯数字的密码！',top.location='../?!=register')</script>";
  exit;
}
if(!file_exists($fil)){
$fp=fopen($fil,"w");
fputs($fp,"0");
fclose($fp);
}
$fp=fopen($fil,"r");
$hits=fgets($fp,1024);
fclose($fp);
$hits=$hits + 1;
$hits=(string)$hits;
$fp=fopen($fil,"w");
fputs($fp,$hits);
fclose($fp);
for($i=0;$i<10;$i++)
$hits = str_replace("$i","$i","$hits");
$user="../user/".$username.".php";
$u="$"."un=";
$p="$"."pw=";
$d="$"."uid=";
$usq="<?php $u'$username';$p'$password';$d'$hits';?>";
if(!file_exists($user)){
$fp=fopen($user,"w");
fputs($fp,$usq);
fclose($fp);
echo "<script>alert('注册成功！',top.location='../?!=login')</script>";
}else{
echo "<script>alert('注册失败！',top.location='../?!=register')</script>";
}