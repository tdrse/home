<?php
 	$f_name = "num.txt";
	if(!file_exists($f_name)){
 	$fp=fopen($f_name,"w");
 	fputs($fp,"0");
 	fclose($fp);}
 	$fp=fopen($f_name,"r");
 	$hits=fgets($fp,1024);
 	fclose($fp);
 	$hits=$hits + 1;
 	$hits=(string)$hits;
 	$fp=fopen($f_name,"w");
 	fputs($fp,$hits);
 	fclose($fp);
	for($i=0;$i<10;$i++) 
	$hits = str_replace("$i","$i","$hits");
	echo $hits;   
?>