<?php
$intime=999 * 3600;
session_set_cookie_params($intime);
session_start();
$lang=$_SESSION['lang'];
if($lang=='en'){
date_default_timezone_set('UTC');
}else{
date_default_timezone_set('PRC');
}
$get=$_GET['code'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no,target-densitydpi=device-dpi">
<title>InOFTD</title>
</head>
<body>
<style>
/*@font-face{
font-family:font;
src:url('');
}*/
*::-webkit-scrollbar {display:none}
*{
font-family:font;
outline:none;
box-sizing:border-box;
-webkit-text-size-adjust: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
-moz-user-select:none;
-webkit-user-select:none;
-ms-user-select:none;
-khtml-user-select:none;
-o-user-select:none;
user-select:none;
}
a{
text-decoration:none;
}
body{
margin:0;
width:100%;
height:100%;
background:#fff;
}
#indiv{
position:fixed;
width:100%;
height:100%;
background:#fff;
z-index:-1;
}
#ting{
position:fixed;
width:100%;
height:40px;
bottom:0px;
padding:0px 10px 0px 10px;
background:#fff;
font-size:18px;
border:0px solid #000;
border-radius:0px;
vertical-align:middle;
word-break:break-all;
box-shadow:0 2px 6px 0 rgba(0,0,0,.2);
transition:all 0.3s;
}
#janp{
position:fixed;
bottom:0px;
left:0px;
display:none;
width:100%;
height:160px;
border:0px solid #000;
background:#fff;
padding:5px;
}
table{
border-style:none;
border-collapse:collapse;
width:100%;
height:120px;
border:0px solid #000;
}
td{
padding:0px;
margin:0;
width:calc(100% / 10);
vertical-align:middle;
height:37px;
border:0px solid #000;
border-radius:0px;
text-align:center;
}
/*table tr td div{
position:relative;
font-size:14px;
line-height:20px;
width:100%;
height:40px;
border:1px solid #f00;
padding:10px;
background:#978;
}*/
#date{
padding:10px;
}
#tinde{
font-size:24px;
}
</style>
<script>
setInterval(function(){
var date = new Date();
var week=date.getDay();
var are=['周日','周一','周二','周三','周四','周五','周六',''];
if(date.getMinutes() <= 9){
var z=0;
}else{
var z='';
}
document.getElementById('date').innerHTML='<div id=tinde>' + date.getHours() + ':' + z + date.getMinutes() + '</div> ' + are[week];
},0);
function toput(n){
//document.getElementById('')
if(n==0){
document.getElementById('ting').style.bottom='160px';
document.getElementById('ting').style.left='0px';
document.getElementById('janp').style.display='block';
document.onkeydown=function(event){
var event=event||window.event;
if(event.keyCode=='8'){
document.getElementById('ting').value=document.getElementById('ting').value.slice(0,-1);
}
if(event.keyCode=='32'){
document.getElementById('ting').value='';
}
if(event.keyCode=='48'){
document.getElementById('ting').value+='0';
}
if(event.keyCode=='49'){
document.getElementById('ting').value+='1';
}
if(event.keyCode=='50'){
document.getElementById('ting').value+='2';
}
if(event.keyCode=='51'){
document.getElementById('ting').value+='3';
}
if(event.keyCode=='52'){
document.getElementById('ting').value+='4';
}
if(event.keyCode=='53'){
document.getElementById('ting').value+='5';
}
if(event.keyCode=='54'){
document.getElementById('ting').value+='6';
}
if(event.keyCode=='55'){
document.getElementById('ting').value+='7';
}
if(event.keyCode=='56'){
document.getElementById('ting').value+='8';
}
if(event.keyCode=='57'){
document.getElementById('ting').value+='9';
}
if(event.keyCode=='65'){
document.getElementById('ting').value+='A';
}
if(event.keyCode=='66'){
document.getElementById('ting').value+='B';
}
if(event.keyCode=='67'){
document.getElementById('ting').value+='C';
}
if(event.keyCode=='68'){
document.getElementById('ting').value+='D';
}
if(event.keyCode=='69'){
document.getElementById('ting').value+='E';
}
if(event.keyCode=='70'){
document.getElementById('ting').value+='F';
}
if(event.keyCode=='71'){
document.getElementById('ting').value+='G';
}
if(event.keyCode=='72'){
document.getElementById('ting').value+='H';
}
if(event.keyCode=='73'){
document.getElementById('ting').value+='I';
}
if(event.keyCode=='74'){
document.getElementById('ting').value+='J';
}
if(event.keyCode=='75'){
document.getElementById('ting').value+='K';
}
if(event.keyCode=='76'){
document.getElementById('ting').value+='L';
}
if(event.keyCode=='77'){
document.getElementById('ting').value+='M';
}
if(event.keyCode=='78'){
document.getElementById('ting').value+='N';
}
if(event.keyCode=='79'){
document.getElementById('ting').value+='O';
}
if(event.keyCode=='80'){
document.getElementById('ting').value+='P';
}
if(event.keyCode=='81'){
document.getElementById('ting').value+='Q';
}
if(event.keyCode=='82'){
document.getElementById('ting').value+='R';
}
if(event.keyCode=='83'){
document.getElementById('ting').value+='S';
}
if(event.keyCode=='84'){
document.getElementById('ting').value+='T';
}
if(event.keyCode=='85'){
document.getElementById('ting').value+='U';
}
if(event.keyCode=='86'){
document.getElementById('ting').value+='V';
}
if(event.keyCode=='87'){
document.getElementById('ting').value+='W';
}
if(event.keyCode=='88'){
document.getElementById('ting').value+='X';
}
if(event.keyCode=='89'){
document.getElementById('ting').value+='Y';
}
if(event.keyCode=='90'){
document.getElementById('ting').value+='Z';
}


}
}else{
document.getElementById('ting').style.bottom='';
document.getElementById('ting').style.left='';
document.getElementById('janp').style.display='';
document.onkeydown=function(event){
var event=event||window.event;
document.getElementById('ting').value=document.getElementById('ting').value;
}
}
}
function ptod(n){
if(n=='⌫'){
document.getElementById('ting').value=document.getElementById('ting').value.slice(0,-1);
}else if(n=='✕'){
toput(1);
}else if(n=='#'){
document.getElementById('ting').value='';
}else{
document.getElementById('ting').value+=n;
}
}

</script>
<div id="indiv">
<div id="date"></div>
<input id="ting" readonly onclick="toput(0)">
<div id="janp">
<table>
<tr>
<td><div onclick="ptod(this.innerText)">0</div></td>
<td><div onclick="ptod(this.innerText)">1</div></td>
<td><div onclick="ptod(this.innerText)">2</div></td>
<td><div onclick="ptod(this.innerText)">3</div></td>
<td><div onclick="ptod(this.innerText)">4</div></td>
<td><div onclick="ptod(this.innerText)">5</div></td>
<td><div onclick="ptod(this.innerText)">6</div></td>
<td><div onclick="ptod(this.innerText)">7</div></td>
<td><div onclick="ptod(this.innerText)">8</div></td>
<td><div onclick="ptod(this.innerText)">9</div></td>
</tr>
<tr>
<td><div onclick="ptod(this.innerText)">Q</div></td>
<td><div onclick="ptod(this.innerText)">W</div></td>
<td><div onclick="ptod(this.innerText)">E</div></td>
<td><div onclick="ptod(this.innerText)">R</div></td>
<td><div onclick="ptod(this.innerText)">T</div></td>
<td><div onclick="ptod(this.innerText)">Y</div></td>
<td><div onclick="ptod(this.innerText)">U</div></td>
<td><div onclick="ptod(this.innerText)">I</div></td>
<td><div onclick="ptod(this.innerText)">O</div></td>
<td><div onclick="ptod(this.innerText)">P</div></td>
</tr>
<tr>
<td><div onclick="ptod(this.innerText)">A</div></td>
<td><div onclick="ptod(this.innerText)">S</div></td>
<td><div onclick="ptod(this.innerText)">D</div></td>
<td><div onclick="ptod(this.innerText)">F</div></td>
<td><div onclick="ptod(this.innerText)">G</div></td>
<td><div onclick="ptod(this.innerText)">H</div></td>
<td><div onclick="ptod(this.innerText)">J</div></td>
<td><div onclick="ptod(this.innerText)">K</div></td>
<td><div onclick="ptod(this.innerText)">L</div></td>
<td><div onclick="ptod(this.innerText)">⌫</div></td>
</tr>
<tr>
<td><div onclick="ptod(this.innerText)">Z</div></td>
<td><div onclick="ptod(this.innerText)">X</div></td>
<td><div onclick="ptod(this.innerText)">C</div></td>
<td><div onclick="ptod(this.innerText)">V</div></td>
<td><div onclick="ptod(this.innerText)">B</div></td>
<td><div onclick="ptod(this.innerText)">N</div></td>
<td><div onclick="ptod(this.innerText)">M</div></td>
<td><div onclick="ptod(this.innerText)">#</div></td>
<td colspan="2"><div onclick="ptod(this.innerText)">✕</div></td>
</tr>
</table>
</div>

</div>
</body>
</html>