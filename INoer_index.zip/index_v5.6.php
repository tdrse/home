<?php
$intime=999 * 3600;
session_set_cookie_params($intime);
session_start();
$lang=$_SESSION['lang'];
if($lang=='en'){
date_default_timezone_set('UTC');
}else{
date_default_timezone_set('PRC');
}
$get=$_GET['code'];
?>
<!DOCTYPE html>
<html onselectstart="return false" oncontextmenu="window.event.returnValue=false">
<head>
<meta charset="utf-8" name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no,target-densitydpi=device-dpi">
<title>INTDR</title>
</head>
<body>
<style>
/*@font-face{
font-family:font;
src:url('');
}*/
*::-webkit-scrollbar {display:none}
*{
font-family:font;
outline:none;
box-sizing:border-box;
-webkit-text-size-adjust: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
-moz-user-select:none;
-webkit-user-select:none;
-ms-user-select:none;
-khtml-user-select:none;
-o-user-select:none;
user-select:none;
}
a{
text-decoration:none;
}
body{
margin:0;
width:100%;
height:100%;
background:#fff;
}
#indiv{
position:fixed;
width:100%;
height:100%;
background:#fff;
z-index:-1;
}
#ting{
//pointer-events:none;
position:fixed;
width:100%;
height:40px;
bottom:0px;
padding:0px 10px 0px 10px;
overflow-y:scroll;
background:#fff;
font-size:18px;
border:0px solid #000;
border-radius:0px;
vertical-align:middle;
word-break:break-all;
transition:all 0.3s;
}
#janp{
position:fixed;
bottom:-160px;
left:0px;
width:100%;
height:160px;
border:0px solid #000;
background:#fff;
padding:5px;
transition:all 0.3s;
border-style:none;
border-collapse:collapse;
}
td{
padding:0px;
margin:0px;
font-size:16px;
width:calc(100% / 10);
border:0px solid #000;
border-radius:0px;
text-align:center;
}
td:active{
//color:#ff0;
}
#datex{
width:100%;
padding:10px;
}
#tinde{
font-size:24px;
}
#tfoa{
position:fixed;
top:-100px;
width:100%;
height:100px;
padding:10px;
background:#fff;
transition:all 0.3s;
border:0px solid #000;
}
#iota{
font-size:16px;
height:56px;
border:0px solid #000;
transition:all 90ms;
}
#quit{
height:24px;
text-align:right;
border:0px solid #000;
}
#quit a{
border-bottom:1px solid #000;
}
#blak{
color:#fff;
padding:0 2px 0 2px;
border:1px solid #000;
border-radius:0px;
background:#fff;
transition:all 0.3s;
}
#blak:hover{
background:#000;
}
</style>
<script>
setInterval(function(){

var date = new Date();
var year=date.getFullYear();
var mon=date.getMonth()+1;
var day=date.getDate();
var week=date.getDay();
var are=['周日','周一','周二','周三','周四','周五','周六',''];
if(date.getMinutes() <= 9){
var z=0;
}else{
var z='';
}
document.getElementById('datex').innerHTML='<a id="tinde">' + date.getHours() + ':' + z + date.getMinutes() + '</a><br><a>' + are[week] + '</a>';

var hour=date.getHours();
hour=parseInt(hour);
if(hour <= parseInt(4)){
var apm='深夜';
}else{
if(hour <= parseInt(6)){
var apm='凌晨';
}else{
if(hour <= parseInt(9)){
var apm='早上';
}else{
if(hour <= parseInt(12)){
var apm='上午';
}else{
if(hour < parseInt(18)){
var apm='下午';
hour=hour-12;
}else{
if(hour < parseInt(20)){
var apm='傍晚';
hour=hour-12;
}else{
if(hour < parseInt(24)){
var apm='晚上';
hour=hour-12;
}
}
}
}
}
}
}
document.getElementById('datey').innerHTML='<a id="tinde">' + hour + ':' + z + date.getMinutes() + '</a>&nbsp;<a>' + are[week] + apm + '</a>';

document.getElementById('datez').innerHTML=year + '/' + mon + '/' + day;
},0);

function tdpe(){
if(document.getElementById('tfoa').style.top!=='0px'){
document.getElementById('tfoa').style.top='0px';
document.getElementById('tfoa').style.left='0px';
setTimeout(function(){
document.getElementById('tfoa').style.boxShadow='0 0 6px 0 rgba(0,0,0,.1)';
},90);
}else{
document.getElementById('tfoa').style.top='';
document.getElementById('tfoa').style.left='';
document.getElementById('tfoa').style.boxShadow='';
}
}
function cyrt(n){
var wt=document.getElementById('iota').innHTML;
if(n==0){
document.getElementById('iota').style.opacity='0';
setTimeout(function(){
document.getElementById('iota').style.opacity='1';
document.getElementById('iota').innerHTML='<div>Auther : tdrse<br>Version : 5.6 Alpha<br>Update : 2022/7/30</div>';
},90);
document.getElementById('auth').setAttribute('onclick','cyrt(1)');
}else{
document.getElementById('iota').style.opacity='0';
setTimeout(function(){
document.getElementById('iota').style.opacity='1';
document.getElementById('iota').innerHTML='<div id="datey"></div><div id="datez"></div>';
},90);
document.getElementById('auth').setAttribute('onclick','cyrt(0)');

}
}
function ptod(n){
if(n=='⌫'){
document.getElementById('ting').value=document.getElementById('ting').value.slice(0,-1);
}else if(n=='✕'){
toput(1);
}else if(n=='[-n]'){
document.getElementById('ting').value='';
}else if(n=='EN'){
document.getElementById('dx').innerText='en';
var k='abcdefghijklmnopqrstuvwxyz';
}else if(n=='en'){
document.getElementById('dx').innerText='EN';
var k='ABCDEFGHIJKLMNOPQRSTUVWXYZ';
}else{
var dx=document.getElementById('dx').innerText;
if(dx=='EN'){
document.getElementById('ting').value+=n.toUpperCase();
}else{
document.getElementById('ting').value+=n;
}
}
var keyall=new Array();
var keyall=k.split('');
document.getElementById('a').innerText=keyall[0];
document.getElementById('b').innerText=keyall[1];
document.getElementById('c').innerText=keyall[2];
document.getElementById('d').innerText=keyall[3];
document.getElementById('e').innerText=keyall[4];
document.getElementById('f').innerText=keyall[5];
document.getElementById('g').innerText=keyall[6];
document.getElementById('h').innerText=keyall[7];
document.getElementById('i').innerText=keyall[8];
document.getElementById('j').innerText=keyall[9];
document.getElementById('k').innerText=keyall[10];
document.getElementById('l').innerText=keyall[11];
document.getElementById('m').innerText=keyall[12];
document.getElementById('n').innerText=keyall[13];
document.getElementById('o').innerText=keyall[14];
document.getElementById('p').innerText=keyall[15];
document.getElementById('q').innerText=keyall[16];
document.getElementById('r').innerText=keyall[17];
document.getElementById('s').innerText=keyall[18];
document.getElementById('t').innerText=keyall[19];
document.getElementById('u').innerText=keyall[20];
document.getElementById('v').innerText=keyall[21];
document.getElementById('w').innerText=keyall[22];
document.getElementById('x').innerText=keyall[23];
document.getElementById('y').innerText=keyall[24];
document.getElementById('z').innerText=keyall[25];
}
function toput(n){
if(n==0){
document.getElementById('ting').style.bottom='160px';
document.getElementById('ting').style.left='0px';
document.getElementById('janp').style.bottom='0px';
setTimeout(function(){
document.getElementById('ting').style.boxShadow='0 2px 6px 0 rgba(0,0,0,.2)';
},90);
document.onkeydown=function(event){
var event=event||window.event;
var dx=document.getElementById('dx').innerText;
if(event.keyCode=='8'){
document.getElementById('ting').value=document.getElementById('ting').value.slice(0,-1);
}
if(event.keyCode=='16'){
ptod(dx);
}
if(event.keyCode=='32'){
document.getElementById('ting').value='';
}
if(event.keyCode=='48'){
var cky='0';
}else if(event.keyCode=='49'){
var cky='1';
}else if(event.keyCode=='50'){
var cky='2';
}else if(event.keyCode=='51'){
var cky='3';
}else if(event.keyCode=='52'){
var cky='4';
}else if(event.keyCode=='53'){
var cky='5';
}else if(event.keyCode=='54'){
var cky='6';
}else if(event.keyCode=='55'){
var cky='7';
}else if(event.keyCode=='56'){
var cky='8';
}else if(event.keyCode=='57'){
var cky='9';
}else if(event.keyCode=='65'){
var cky='A';
}else if(event.keyCode=='66'){
var cky='B';
}else if(event.keyCode=='67'){
var cky='C';
}else if(event.keyCode=='68'){
var cky='D';
}else if(event.keyCode=='69'){
var cky='E';
}else if(event.keyCode=='70'){
var cky='F';
}else if(event.keyCode=='71'){
var cky='G';
}else if(event.keyCode=='72'){
var cky='H';
}else if(event.keyCode=='73'){
var cky='I';
}else if(event.keyCode=='74'){
var cky='J';
}else if(event.keyCode=='75'){
var cky='K';
}else if(event.keyCode=='76'){
var cky='L';
}else if(event.keyCode=='77'){
var cky='M';
}else if(event.keyCode=='78'){
var cky='N';
}else if(event.keyCode=='79'){
var cky='O';
}else if(event.keyCode=='80'){
var cky='P';
}else if(event.keyCode=='81'){
var cky='Q';
}else if(event.keyCode=='82'){
var cky='R';
}else if(event.keyCode=='83'){
var cky='S';
}else if(event.keyCode=='84'){
var cky='T';
}else if(event.keyCode=='85'){
var cky='U';
}else if(event.keyCode=='86'){
var cky='V';
}else if(event.keyCode=='87'){
var cky='W';
}else if(event.keyCode=='88'){
var cky='X';
}else if(event.keyCode=='89'){
var cky='Y';
}else if(event.keyCode=='90'){
var cky='Z';
}else{
var cky='';
}

if(dx=='EN'){
document.getElementById('ting').value+=cky;
}else{
document.getElementById('ting').value+=cky.toLowerCase();
}

}
}else{
document.getElementById('ting').style.bottom='';
document.getElementById('ting').style.left='';
document.getElementById('ting').style.boxShadow='';
document.getElementById('janp').style.bottom='';
if(document.getElementById('ting').value==''){
document.getElementById('ting').value='⌨';
}
document.onkeydown=function(event){
var event=event||window.event;
document.getElementById('ting').value=document.getElementById('ting').value;
}
}
}
document.onmousedown=function(event){
var event=event||window.event;
if(event.button==2){
if(document.getElementById('janp').style.bottom=='0px'){
toput(1);
}else{
toput(0);
}
}
if(event.button==1){
tdpe();
}
}
</script>
<div id="indiv">
<div id="tfoa">
<div id="iota">
<div id="datey"></div>
<div id="datez"></div>
</div>
<div id="quit"><a id="auth" onclick="cyrt(0)">?</a>&nbsp;<a onclick="tdpe()">✕</a></div>
</div>
<div id="datex" onclick="tdpe()"></div>
<input id="ting" readonly onclick="toput(0)" value='⌨'>
<table id="janp">
<tr>
<td id="zero" onclick="ptod(this.innerText)">0</td>
<td id="one" onclick="ptod(this.innerText)">1</td>
<td id="two" onclick="ptod(this.innerText)">2</td>
<td id="three" onclick="ptod(this.innerText)">3</td>
<td id="four" onclick="ptod(this.innerText)">4</td>
<td id="five" onclick="ptod(this.innerText)">5</td>
<td id="six" onclick="ptod(this.innerText)">6</td>
<td id="seven" onclick="ptod(this.innerText)">7</td>
<td id="eight" onclick="ptod(this.innerText)">8</td>
<td id="nine" onclick="ptod(this.innerText)">9</td>
</tr>
<tr>
<td id="q" onclick="ptod(this.innerText)">q</td>
<td id="w" onclick="ptod(this.innerText)">w</td>
<td id="e" onclick="ptod(this.innerText)">e</td>
<td id="r" onclick="ptod(this.innerText)">r</td>
<td id="t" onclick="ptod(this.innerText)">t</td>
<td id="y" onclick="ptod(this.innerText)">y</td>
<td id="u" onclick="ptod(this.innerText)">u</td>
<td id="i" onclick="ptod(this.innerText)">i</td>
<td id="o" onclick="ptod(this.innerText)">o</td>
<td id="p" onclick="ptod(this.innerText)">p</td>
</tr>
<tr>
<td id="a" onclick="ptod(this.innerText)">a</td>
<td id="s" onclick="ptod(this.innerText)">s</td>
<td id="d" onclick="ptod(this.innerText)">d</td>
<td id="f" onclick="ptod(this.innerText)">f</td>
<td id="g" onclick="ptod(this.innerText)">g</td>
<td id="h" onclick="ptod(this.innerText)">h</td>
<td id="j" onclick="ptod(this.innerText)">j</td>
<td id="k" onclick="ptod(this.innerText)">k</td>
<td id="l" onclick="ptod(this.innerText)">l</td>
<td onclick="ptod(this.innerText)">⌫</td>
</tr>
<tr>
<td id="z" onclick="ptod(this.innerText)">z</td>
<td id="x" onclick="ptod(this.innerText)">x</td>
<td id="c" onclick="ptod(this.innerText)">c</td>
<td id="v" onclick="ptod(this.innerText)">v</td>
<td id="b" onclick="ptod(this.innerText)">b</td>
<td id="n" onclick="ptod(this.innerText)">n</td>
<td id="m" onclick="ptod(this.innerText)">m</td>
<td id="dx" onclick="ptod(this.innerText)">en</td>
<td onclick="ptod(this.innerText)">[-n]</td>
<td onclick="ptod(this.innerText)">✕</td>
</tr>
</table>

</div>
</body>
</html>