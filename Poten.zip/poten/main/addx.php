<html onselectstart="return false"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" charset="utf-8"/><link rel="stylesheet" href="swiper.min-4.2.2.css">
<script>
function showerrimg(obj){
     var errorimg = "error.jpg";
     obj.src = errorimg;
}
</script>
    <style>
        .swiper-container {
            width: 100%;
            height: 200px;
            margin: 0 auto;
            border-bottom:0.01rem solid #ccc;
        }
        .swiper-slide {
            overflow: hidden;
            background:#fff;
            pointer-events:none;
        }
    </style>
<body style="margin:0;padding:0;">
<div id="sw" class="swiper-container">
    <div class="swiper-wrapper">
        <div class="swiper-slide">
            <div class="swiper-zoom-container">
                <img src="http://to.synergize.co/newpor/poten/main/img/a.jpeg" onerror="showerrimg(this);">
            </div>
        </div>
        <div class="swiper-slide">
            <div class="swiper-zoom-container">
                <img src="http://to.synergize.co/newpor/poten/main/img/b.jpg" onerror="showerrimg(this);">
            </div>
        </div>
        <div class="swiper-slide">
            <div class="swiper-zoom-container">
                <img src="http://to.synergize.co/newpor/poten/main/img/c.jpg" onerror="showerrimg(this);">
            </div>
        </div>
        <div class="swiper-slide">
            <div class="swiper-zoom-container">
                <img src="http://to.synergize.co/newpor/poten/main/img/d.png" onerror="showerrimg(this);">
            </div>
        </div>
        <div class="swiper-slide">
            <div class="swiper-zoom-container">
                <img src="http://to.synergize.co/newpor/poten/main/img/e.png" onerror="showerrimg(this);">
            </div>
        </div>
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination swiper-pagination-white"></div>
    <!-- Add Navigation -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>

</div>
<script src="swiper.min-4.2.2.js"></script>
<script>
  var swiper = new Swiper('.swiper-container', {
    zoom: true,
    pagination: {
      el: '.swiper-pagination',
      type:'fraction'
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });
</script>
</html>