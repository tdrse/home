<html onselectstart="return false"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" charset="utf-8"/>
<body style="margin:0;padding:0;">
<style>
object{
pointer-events:none;
border-bottom:0.01rem solid #ccc;
}
.list div{
align:center;
width:100%;
padding:5%;
box-sizing: border-box;
background:#fff;
border-bottom:0.01rem solid #ccc;
}
</style>
<div class="list">
<div>内容1</div>
<div>内容2</div>
<div>内容3</div>
<div>内容4</div>
<div>内容5</div>
<div>内容6</div>
<div>内容7</div>
<div>内容8</div>
<div>内容9</div>
<div>内容0</div>
</div>
</body>
</html>