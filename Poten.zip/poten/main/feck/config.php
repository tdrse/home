<?
// Stores the shouts here
     $shoutsfile = "zisu1u?.e3kso.txt";
// Length of nickname
     $namelength = "20";
// Length of shout message
     $messagelength = "200";
// Maximum shouts
     $max_shouts = 50;

?>