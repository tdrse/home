<?session_start();

?>
<!DOCTYPE HTML>
<html onselectstart="return false">
<body>
<head>
<meta name="viewport" content="width=400, user-scalable=no" />
<title>SHOUT</title>
<script language="javascript">
<!--
function openwindow(theURL,winName,features) {
  window.open(theURL,winName,features);
}
-->
</script>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body class="background">
<div class="outerdiv">
<object data="show.php" name="shouts" noresize="noresize" class="iframe"></object>
<div style="text-align:center">
<form action="show.php" name="shoutform" method="POST" enctype="multipart/form-data" target="shouts">
<?
 if(isset($_SESSION['name'])) {
        echo "<input name=\"name\" type=\"text\" class=\"textname\" value=\"".$_SESSION['name']."\"  onfocus=\"if(this.value==this.defaultValue)this.value='';\" onblur=\"if(this.value=='')this.value=this.defaultValue;\"/><br>";
}else{
        echo "<input name=\"name\" type=\"text\" class=\"textname\" value=\"匿名用户\" onfocus=\"if(this.value==this.defaultValue)this.value='';\" onblur=\"if(this.value=='')this.value=this.defaultValue;\"/><br>";
}
?>
<input name="message" type="text" rows ="2" class="textarea" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><table style="width:100%"><div><input type="submit" value="发送" class="formbtn"/><input type="reset" value="清除" class="formbtn"/></div></table>
<table style="width:100%"><div class="boxtext"><a onClick="window.location.href='mailto:tdrse@outlook.com';return false">© tdrse</a></div></table>
<div style="color:#fff">注：点击一次即可发送反馈，请减少多次发送</div>
</form>
</div>
</div>
</body>
</html>