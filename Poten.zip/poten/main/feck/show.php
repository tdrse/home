<?
session_start();
include("config.php");
$_SESSION['name']=$_REQUEST['name'];
$message=$_REQUEST['message'];

   if ( isset($_SERVER["REMOTE_ADDR"]) )    {
    $ip_address=$_SERVER["REMOTE_ADDR"] . ' ';
   } else if ( isset($_SERVER["HTTP_X_FORWARDED_FOR"]) )    {
    $ip_address=$_SERVER["HTTP_X_FORWARDED_FOR"] . ' ';
   } else if ( isset($_SERVER["HTTP_CLIENT_IP"]) )    {
    $ip_address=$_SERVER["HTTP_CLIENT_IP"] . ' ';
   }

if (file_exists($badips)) {
    $fp=fopen($badips, 'r');
    while (!feof($fp)){
      $line=fgets($fp);
      if ($line != ""){
        if (strpos($ip_address, trim($line)) !== false){
          error("您的IP地址已被禁用");
          exit;
        }
      }
    }
    fclose($fp);
}

if (file_exists($badwords)) {
    $fp=fopen($badwords, 'r');
    while (!feof($fp)){
      $line=fgets($fp);
      if ($line !=""){
         $line=strtolower($line);
         if (strpos($_SESSION['name'], trim($line)) !== false){
           error("此名称已被禁止<br>请换一个");
           exit;
         }
         if (strpos(strtolower($message), trim($line)) !== false){
           $message = str_replace(trim($line), '***', $message);
         }
      }
    }
    fclose($fp);
}

if ( strlen($_SESSION['name']) >= $namelength ){
   $_SESSION['name'] = substr($_SESSION['name'],0,$namelength)."..";
}
if ( strlen($message) >= $messagelength ){
   $message = substr($message,0,$messagelength)."...";
}
$message = stripslashes($message);
$message = htmlspecialchars($message);
$message = strip_tags($message);
$entry = "<span style=\"color:black\"><b>&#x005b;".$_SESSION['name']."&#x005d;</b> ".$message."</span>|".$ip_address;
for ($j=1; $j<=50; $j++) {
  $entry = str_replace (':smiley'.$j.':',' <img src="smileys/smiley'.$j.'.gif">',$entry);
}

if ($message !="" && $_SESSION['name'] !=""){
  if (file_exists($shoutsfile)) {
     $lines = file($shoutsfile);
     $count=count($lines);
     if ($count >= $max_shouts){
        unset($lines[0]);
        $fp=fopen($shoutsfile, 'w');
	     if (flock($fp,LOCK_EX)) {
           for ($i=0; $i<=$count; $i++) {
              fwrite($fp,$lines[$i]);
		   }
           fwrite($fp,$entry."\r\n");
         flock($fp,LOCK_UN);
         }
     }else{
        file_put_contents($shoutsfile, $entry."\r\n", FILE_APPEND);
	 }

  }
}
$lines = file($shoutsfile);

echo "<!doctype html>";
echo "<html>";
echo "<head>";
echo "<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">";
echo "</head>";
echo "<body class=\"background\">";
for ($i = count($lines) - 1; $i >=0 ; $i--) {
  $pieces = explode("|", $lines[$i]);
  echo "<div class=\"shouts\">".$pieces[0]."</div>";
}


echo "</body>";
echo "</html>";
exit;



function error($message) {
?>
   <!DOCTYPE HTML>
   <html>
   <head>
   <title>Error !</title>
   <link rel="stylesheet" href="style.css" type="text/css">
   <meta name="robots" content="noindex">
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   </head>
   <body class="background">
     <br><br><br><br><div style="text-align:center">
   		<b><?=$message?></b><br><br>
    </div>
    </body>
    </html>
<?
exit;
}

