<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" charset="utf-8"/>
空闲公告...需要经常清除数据(因为图片会被缓存)。。。唉唉唉