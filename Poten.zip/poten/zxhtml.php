<html onselectstart="return false"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" charset="utf-8"/>
<body style="margin:0;padding:0;">
<style>
.btn div{
align:center;
width:100%;
padding:5%;
box-sizing: border-box;
background:#fff;
border-bottom:0.01rem solid #ccc;
}
</style>
<div class="btn">
<div><b>在线HTML</b></div>
<div>暂无</div>
</div>
</body>
</html>