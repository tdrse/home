<?php
$otime=999*3600;
session_set_cookie_params($otime); 
session_start();
date_default_timezone_set('PRC');
$get=$_GET['!'];
$uen=$_GET['u'];
$lug=$_GET['lang'];
$year=date('Y');
$time = date('Y/m/d');
$nowtime = date('H:i:s');


$officekey="mykey";

/*
$ua=$_SERVER['HTTP_USER_AGENT'];
$ofkey="tdrOF/key-of-app/web+@opui>>>tdrse:ua";
if($ua!==$ofkey){?>
<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>
<html onselectstart='return false'><div>Error<br>Ua:<a style='color:#555'><?php echo $ua;?></a><br>Time:<a style='color:#555'><?php echo $time.' '.$nowtime;?></a></div>
</html>
<?php exit;}
*/


$lang_cn=array(
  '0' => '系统错误',
  '1' => '工作室',
  '2' => '登出成功',
  '3' => '请输入用户名',
  '4' => '没有此用户',
  '5' => '登录成功',
  '6' => '账号或密码不正确',
  '7' => '用户已存在',
  '8' => '账号或密码不符合要求',
  '9' => '账号或密码不能含有空格',
  '10' => '请输入密码',
  '11' => '请输入用户名',
  '12' => '请勿设置纯数字的密码',
  '13' => '两次密码不一致',
  '14' => '注册成功',
  '15' => '注册失败',
  '16' => '注册',
  '17' => 'TDR工作室',
  '18' => '用户名 1～10位',
  '19' => '密码 6～32位',
  '20' => '确认密码',
  '21' => '立即注册',
  '22' => '登录',
  '23' => '用户名',
  '24' => '密码',
  '25' => '立即登录',
  '26' => '注册一个账号',
  '27' => '重置',
  '28' => '原密码',
  '29' => '新密码 6～32位',
  '30' => '立即修改',
  '31' => '反馈',
  '32' => '反馈信息',
  '33' => '发送反馈',
  '34' => '确定要退出登录',
  '35' => '退登',
  '36' => '设置',
  '37' => '背景虚化',
  '38' => '已开启',
  '39' => '已关闭',
  '40' => '修改密码',
  '41' => '问题反馈',
  '42' => '选择语言',
  '43' => '概念',
  '44' => '确定',
  '45' => '取消',
  '46' => '简体中文',
  '47' => '当前语言',
  '48' => '选择语言',
  '49' => '修改成功',
  '50' => '修改失败',
  '51' => '原密码错误',
  '52' => '密码不符合要求',
  '53' => '密码不能含有空格',
  '54' => '请输入新密码',
  '55' => '请输入旧密码',
  '56' => '暂时没有数据',
);
$lang_en=array(
  '0' => 'System error',
  '1' => 'TDR Office',
  '2' => 'Logout already',
  '3' => 'Please enter your username',
  '4' => 'Without this user',
  '5' => 'Successful login',
  '6' => 'Account or password is incorrect',
  '7' => 'User already exists',
  '8' => 'Account or password does not meet the requirements',
  '9' => 'Account or password can not contain spaces',
  '10' => 'Please enter your password',
  '11' => 'Please enter your username',
  '12' => 'Do not set up pure numbers',
  '13' => 'Two passwords are inconsistent',
  '14' => 'Register successfully',
  '15' => 'Registration failed',
  '16' => 'Register',
  '17' => 'Tdrofi',
  '18' => 'User name 1 ~ 10 digits',
  '19' => 'Password 6 ~ 32 digits',
  '20' => 'Validate password',
  '21' => 'Register now',
  '22' => 'Login',
  '23' => 'Username',
  '24' => 'Password',
  '25' => 'Log in now',
  '26' => 'Register an account',
  '27' => 'Reset',
  '28' => 'Old password',
  '29' => 'New password 6～32 digits',
  '30' => 'Now reset',
  '31' => 'Feedback',
  '32' => 'Feedback information',
  '33' => 'Send feedback',
  '34' => 'Really to quit login',
  '35' => 'Logout',
  '36' => 'Setting',
  '37' => 'Background blur',
  '38' => 'On',
  '39' => 'Off',
  '40' => 'Reset password',
  '41' => 'To feedback',
  '42' => 'Language',
  '43' => 'Notion',
  '44' => 'OK',
  '45' => 'Cancel',
  '46' => 'English',
  '47' => 'Now language',
  '48' => 'Select language',
  '49' => 'Successful',
  '50' => 'Modification Failed',
  '51' => 'Old password is incorrect',
  '52' => 'Password does not meet the requirements',
  '53' => 'Password can not contain spaces',
  '54' => 'Please enter a new password',
  '55' => 'Please enter the old password',
  '56' => 'No anything',
);
$language=$_SESSION['weofandtdrlang'];
if($language=="en"){$lang=$lang_en;}else{$lang=$lang_cn;$_SESSION['weofandtdrlang']="cn";}





$udir="./tmu";





if(!is_dir($udir)) {
if(!mkdir($udir, 0775, true)){error($lang[0]);exit;}}




if($_SESSION['weofficekey'] && $_SESSION['wenamesandin'] && $_SESSION['weofficeserm'] && $_SESSION['weallnameorkey']){


$saying = 'data.php';
if(file_exists($saying)){
header('Content-type: text/html; charset=utf-8');
$data=file_get_contents($saying);
$data=explode(PHP_EOL, $data);
$result=$data[array_rand($data)];
$one=str_replace('*/?>','',str_replace('<?php /*','',$result));
$two=str_replace(array("\r","\n","\r\n"),'',$one);
}


if($get=="lang-uage"){
if($lug=="cn" && $language!=='cn'){
$_SESSION['weofandtdrlang']="cn";
echo "<script>top.location='?!=index'</script>";
exit;
}else if($lug=="en" && $language!=='en'){
$_SESSION['weofandtdrlang']="en";
echo "<script>top.location='?!=index'</script>";
exit;}else{
echo "<script>top.location='?!=index'</script>";}
exit;}



if($get=="re-pw"){
$names=$_SESSION['weallnameorkey'];
require "$udir/$names.tdr.php";
$mofind="$udir/$names.tdr.php";
$oldpass=md5($_POST['oldpassword']);
$newpass=$_POST['newpassword'];
$noem=preg_replace('# #','',$newpass);
$pasu=mb_strlen($noem, 'UTF-8');
$bepass=md5($noem);
if($oldpass=="d41d8cd98f00b204e9800998ecf8427e" && $newpass=="") {exit;}
if($oldpass!=="d41d8cd98f00b204e9800998ecf8427e" && $newpass=="") {echo "<script>alert('$lang[54]',location='./?!=repw')</script>";
exit;}
if($oldpass=="d41d8cd98f00b204e9800998ecf8427e" && $newpass!=="") {echo "<script>alert('$lang[55]',location='./?!=repw')</script>";
exit;}
if(is_numeric($noem)){
echo "<script>alert('$lang[12]',location='./?!=repw')</script>";
exit;}
if($pasu > "32" or $pasu < "6"){
echo "<script>alert('$lang[52]',location='./?!=repw')</script>";
exit;}
if($newpass !== $noem){
echo "<script>alert('$lang[53]',location='./?!=repw')</script>";
exit;}
if($oldpass==$pw){
$sp=md5('tdr'.$bepass.'this_is_fp');
$u="$"."un=";
$p="$"."pw=";
$s="$"."thesm=";
$usin="<?php \n$u'$un';\n$p'$bepass';\n$s'$sp';\n?>";
if(file_exists($mofind)){
$fp=fopen($mofind,"w");
fputs($fp,$usin);
fclose($fp);
echo "<script>alert('$lang[49]',top.location='./?!=logout')</script>";
}else{
echo "<script>alert('$lang[50]',top.location='./?!=index')</script>";
exit;}}else{echo "<script>alert('$lang[51]',top.location='./?!=repw')</script>";exit;}
exit;}



if($get=="ofbg"){
if($_SESSION['weofbgorko']=="on"){
$_SESSION['weofbgorko']="off";
}else{
$_SESSION['weofbgorko']="on";
}
echo "<script>top.location='?!=index'</script>";
exit;
}
$ofbg=$_SESSION['weofbgorko'];



if($get=="bg"){
$img_array = glob('weimg/*.{jpg,png,jpeg,webp,bmp,gif}', GLOB_BRACE);
if(count($img_array) == 0) die(dirname(__FILE__));
header('Content-Type: image/png');
echo(file_get_contents($img_array[array_rand($img_array)]));
exit;
}



if($get==""){echo "<script>location='?!=index'</script>";}




}





if($_SESSION['weofficekey'] or $_SESSION['wenamesandin'] or $_SESSION['weofficeserm'] or $_SESSION['weallnameorkey']){
if($get=="logout"){  /*退出登录*/
unset($_SESSION['weofficekey']);
unset($_SESSION['wenamesandin']);
unset($_SESSION['weofficeserm']);
unset($_SESSION['weallnameorkey']);
echo "<script>alert('$lang[2]',top.location='?!=login')</script>";
exit;}
$names=$_SESSION['weallnameorkey'];
$userth="$udir/$names.tdr.php";
if(file_exists($userth)){require "$udir/$names.tdr.php";}else{echo "<script>location='?!=logout'</script>";exit;}
$thename=md5($un.'tdr'.$pw);
if($_SESSION['weofficekey']!==$officekey or 
$_SESSION['wenamesandin']!==$thename or 
$_SESSION['weofficeserm']!==$thesm){echo "<script>location='?!=logout'</script>";exit;}
}




if(!$_SESSION['weofficekey'] && !$_SESSION['wenamesandin'] && !$_SESSION['weofficeserm'] && !$_SESSION['weallnameorkey']){



if($get==""){echo "<script>location='?!=login'</script>";}



if($get=="log-in"){  /*登录代码*/
$username=$_POST['username'];
$password=md5($_POST['password']);
$username=strip_tags($username);
$username=htmlspecialchars($username); 
$username=addslashes($username);
if ($username=="" && $password=="d41d8cd98f00b204e9800998ecf8427e") {exit;}
if($username=="" & $password !=="d41d8cd98f00b204e9800998ecf8427e"){
echo "<script>alert('$lang[3]')</script>";
exit;}
$name = "$udir/$username.tdr.php";
if(!file_exists($name)){
echo "<script>alert('$lang[4]')</script>";
exit;}
$thename=md5($username.'tdr'.$password);
require "$udir/$username.tdr.php";
if ($password=="$pw") {
$_SESSION['weofficekey']=$officekey;
$_SESSION['wenamesandin']=$thename;
$_SESSION['weofficeserm']=$thesm;
$_SESSION['weallnameorkey']=$username;
echo "<script>alert('$lang[5]',top.location='./')</script>";
}else{echo "<script>alert('$lang[6]')</script>";}
}






if($get=="re-gister"){   /*注册代码*/
$unkp=$_POST['username'];
$tun=preg_replace('# #','',$unkp);
$nasu=mb_strlen($tun, 'UTF-8');
$username=$tun;
$onpas=$_POST['password'];
$nprd=preg_replace('# #','',$onpas);
$pasu=mb_strlen($nprd, 'UTF-8');
$towp=md5($_POST['towpass']);
$password=md5($nprd);
$day = time();
$name = "$udir/$username.tdr.php";
if(file_exists($name)){
echo "<script>alert('$lang[7]',top.location='./?!=register')</script>";
exit;}
if($nasu > "10" or $pasu > "32" or $pasu < "6" && $pasu >= "1"){
echo "<script>alert('$lang[8]',top.location='./?!=register')</script>";
exit;}
if($onpas !== $nprd or $unkp !== $tun){
echo "<script>alert('$lang[9]',top.location='./?!=register')</script>";
exit;}
if($username=="" && $password=="d41d8cd98f00b204e9800998ecf8427e" or $onpas=""){exit;}
if($username !=="" & $password=="d41d8cd98f00b204e9800998ecf8427e"){
echo "<script>alert('$lang[10]')</script>";
exit;}
if($username=="" & $password !=="d41d8cd98f00b204e9800998ecf8427e"){
echo "<script>alert('$lang[11]')</script>";
exit;}
if(is_numeric($nprd)){
echo "<script>alert('$lang[12]',top.location='./?!=register')</script>";
exit;}
if($towp !== $password){
echo "<script>alert('$lang[13]',top.location='./?!=register')</script>";
exit;}
$sp=md5('tdr'.$password.'this_is_fp');
$user=$udir."/".$username.".tdr.php";
$u="$"."un=";
$p="$"."pw=";
$s="$"."thesm=";
$usin="<?php \n$u'$username';\n$p'$password';\n$s'$sp';\n?>";
if(!file_exists($user)){
$fp=fopen($user,"w");
fputs($fp,$usin);
fclose($fp);
echo "<script>alert('$lang[14]',top.location='./?!=login')</script>";
}else{
echo "<script>alert('$lang[15]',top.location='./?!=register')</script>";
exit;}
}





}
?>




<!DOCTYPE html>
<html onselectstart="return false" <?php if($language=="en"){echo "lang='en'";}?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<iframe hidden name="iframe"></iframe>
</head>
<style>
@font-face{
font-family: light;
src: url('cd.woff');
}
*{
font-family:light;
outline:none;
color:#555;
box-sizing:border-box;
-webkit-text-size-adjust: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
-moz-user-select:none;
-webkit-user-select:none;
-ms-user-select:none;
-khtml-user-select:none;
-o-user-select:none;
user-select:none;
}
a{text-decoration:none;}
body{margin:0;width:100%;height:100%;}
</style>
<body>
<div>


<?php
if($get=="user"){
$uento=$udir."/".$uen.".tdr.php";
if(file_exists($uento)){
require $uento;
?>
<html onselectstart="return false">
<title><?php echo $lang[1];?></title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<body>
<style>
*{line-height:16px;font-size:14px;}
body{
width:100%;
height:100%;
-webkit-text-size-adjust: none;
background: url("?!=bg") no-repeat fixed center;
background-size: cover;
background-origin:border-box;
-webkit-tap-highlight-color: rgba(255, 255, 255, 0);
z-index:1;
}
<?php if($ofbg=="on"){?>
body::after{
content: '';
position: fixed;
background:inherit;
z-index:-1;
transform: scale(1, 1);
top: 0;
left: 0;
right: 0;
bottom: 0;
filter: blur(15px);
}
<?php }?>
.mu{
max-width:500px;
text-align:left;
padding:10px;
border-radius:5px;
margin:10px;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
background:rgba(255,255,255,.8);
}
.dtd{
padding:10px;
border-radius:5px;
background:tranparent;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.1s;
}
.dtd:active{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.right{float:right;}
table{width:100%;}
td{padding:2px;margin:0;}
</style>
<div align="center">
<div class="mu">
用户
</div>
<div class="mu">
用户名: <?php echo $un;?>
<br>
ID: unknow
</div>
</div>
<?php }else{?>
oh! not found.
<?php }exit;}
if(!$_SESSION['weofficekey'] && !$_SESSION['wenamesandin'] && !$_SESSION['weofficeserm'] && !$_SESSION['weallnameorkey']){
if($get=="register"){?>


<style>
.main{
max-width:500px;
padding:20px;
}
.register{
margin-bottom:10px;
border-radius:5px;
padding:10px;
line-height:16px;
width:100%;
background:transparent;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.5s;
}
.register:hover{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.fan{
border-radius:5px;
padding:10px;
float:right;
line-height:16px;
background:transparent;
box-sizing:border-box;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.1s;
}
.fan:active{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.user{
text-align:center;
margin-bottom:10px;
}
.dt{
font-size:30px;
padding-bottom:20px;
}
.dt a{
font-size:14px;
padding-bottom:20px;
}
</style>
<title><?php echo $lang[16];?></title>
</head>
<body>
<div align="center">
<div class="main">
<div id="main">
<div class="dt" align="left"><?php echo $lang[16];?><a><?php echo $lang[17];?></a></div>
<form action="?!=re-gister" method="post" target="iframe"><center>
<input class="register" autocomplete="off" type="text" name="username" placeholder="<?php echo $lang[18];?>" maxlength="10">
<input class="register" autocomplete="off" type="password" name="password" placeholder="<?php echo $lang[19];?>" maxlength="32"></center>
<input class="register" autocomplete="off" type="password" name="towpass" placeholder="<?php echo $lang[20];?>" maxlength="32"></center>
<input class="fan" autocomplete="off" type="submit" value="<?php echo $lang[21];?>">
</form>
<div style="font-size:14px;color:#777;float:left"><a onclick="location='?!=login';">＜<?php echo $lang[22];?></a></div>
</div>
</div>
<?php ;exit;}?>





<?php if($get=="login"){?>
<style>
.main{
max-width:500px;
padding:20px;
}
.login{
margin-bottom:10px;
border-radius:5px;
padding:10px;
line-height:16px;
width:100%;
background:transparent;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.5s;
}
.login:hover{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.fan{
border-radius:5px;
padding:10px;
float:right;
line-height:16px;
background:transparent;
box-sizing:border-box;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.1s;
}
.fan:active{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.user{
text-align:center;
margin-bottom:10px;
}
.dt{
font-size:30px;
padding-bottom:20px;
}
.dt a{
font-size:14px;
padding-bottom:20px;
}
</style>
<title><?php echo $lang[22];?></title>
</head>
<body>
<div align="center">
<div class="main">
<div class="dt" align="left"><?php echo $lang[22];?><a><?php echo $lang[17];?></a></div>
<div class="user"><svg version="1.0" xmlns="http://www.w3.org/2000/svg" width="100.000000px" height="100.000000px" viewBox="0 0 500.000000 500.000000" preserveAspectRatio="xMidYMid meet"><g transform="translate(0.000000,500.000000) scale(0.100000,-0.100000)" fill="#555" stroke="none"><path d="M2370 4994 c-309 -36 -536 -112 -753 -251 -594 -380 -887 -1067 -747 -1752 81 -398 312 -758 633 -990 45 -33 90 -66 100 -73 17 -12 11 -17 -65 -47 -485 -195 -942 -591 -1227 -1064 -115 -191 -246 -514 -286 -708 -9 -41 -18 -82 -21 -91 -5 -17 9 -18 204 -18 l209 0 23 88 c195 743 788 1326 1538 1512 327 81 667 84 1002 10 763 -169 1374 -759 1581 -1527 l22 -83 209 0 208 0 -6 28 c-57 253 -114 423 -214 627 -123 254 -281 476 -480 675 -233 234 -519 425 -816 544 l-107 43 29 19 c372 238 636 622 724 1056 97 472 -13 959 -303 1343 -258 342 -649 577 -1072 644 -75 12 -327 22 -385 15z m334 -430 c513 -89 916 -480 1021 -990 98 -475 -115 -997 -519 -1268 -220 -148 -446 -217 -706 -218 -933 0 -1541 1000 -1106 1818 74 138 115 194 225 305 155 155 324 257 530 319 162 50 388 64 555 34z"/></g></svg></div>
<form action="?!=log-in" method="post" name="form" target="iframe"><center>
<input class="login" type="text" name="username" placeholder="<?php echo $lang[23];?>">
<input class="login" type="password" name="password" placeholder="<?php echo $lang[24];?>"></center>
<input class="fan" type="submit" value="<?php echo $lang[25];?>">
</form>
<div style="font-size:14px;color:#777;float:left;"><a onclick="location='?!=register';" target="iframe"><?php echo $lang[26];?>＞</a></div>
</div>
</div>



<?php ;exit;}}?>






<?php if($_SESSION['weofficekey'] && $_SESSION['wenamesandin'] && $_SESSION['weofficeserm'] && $_SESSION['weallnameorkey']){
$names=$_SESSION['weallnameorkey'];
$userth="$udir/$names.tdr.php";
if(file_exists($userth)){require "$udir/$names.tdr.php";}else{echo "<script>location='?!=logout'</script>";exit;}
if($get=="we"){require "we.php";}
if($get=="repw"){?>
<style>
.main{
max-width:500px;
padding:20px;
}
.repw{
margin-bottom:10px;
border-radius:5px;
padding:10px;
line-height:16px;
width:100%;
background:#transparent;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.5s;
}
.repw:hover{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.fan{
border-radius:5px;
padding:10px;
float:right;
line-height:16px;
background:transparent;
box-sizing:border-box;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.1s;
}
.fan:active{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.user{
text-align:center;
margin-bottom:10px;
}
.dt{
font-size:30px;
padding-bottom:20px;
}
.dt a{
font-size:14px;
padding-bottom:20px;
}
</style>
<title><?php echo $lang[27];?></title>
</head>
<body>
<div align="center">
<div class="main">
<div class="dt" align="left"><?php echo $lang[27];?><a><?php echo $lang[17];?><?php echo $lang[24];?></a></div>
<form action="?!=re-pw" method="post" name="form" target="iframe"><center>
<input class="repw" type="text" name="username" readonly placeholder="<?php echo $lang[23];?>: <?php echo $un;?>">
<input class="repw" type="password" name="oldpassword" placeholder="<?php echo $lang[28];?>">
<input class="repw" type="password" name="newpassword" maxlength="32" placeholder="<?php echo $lang[29];?>"></center>
<input class="fan" type="submit" value="<?php echo $lang[30];?>">
</form>
</div>
</div>
<?php ;exit;}
if($get=="feedback"){?>
<style>
.main{
max-width:500px;
padding:20px;
}
.feed{
margin-bottom:10px;
border-radius:5px;
padding:10px;
line-height:16px;
width:100%;
background:transparent;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.5s;
}
.feed:hover{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.fan{
border-radius:5px;
padding:10px;
float:right;
line-height:16px;
background:transparent;
box-sizing:border-box;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.1s;
}
.fan:active{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.user{
text-align:center;
margin-bottom:10px;
}
.dt{
font-size:30px;
padding-bottom:20px;
}
.dt a{
font-size:14px;
padding-bottom:20px;
}
</style>
<title><?php echo $lang[31];?></title>
</head>
<body>
<div align="center">
<div class="main">
<div class="dt" align="left"><?php echo $lang[31];?><a><?php echo $lang[17];?></a></div>
<form action="?!=feed-back" method="post" name="form" target="iframe"><center>
<input class="feed" type="text" name="username" readonly placeholder="<?php echo $lang[23];?>: <?php echo $un;?>">
<input class="feed" style="align:center;" placeholder="<?php echo $lang[32];?>" name="fedin"></input></center>
<input class="fan" type="submit" value="<?php echo $lang[33];?>">
</form>
</div>
</div>
<?php ;exit;}
if($get=="lang"){?>
<style>
*{line-height:16px}
.main{
max-width:500px;
padding:5px;
}
.lang{
margin:3px;
border-radius:5px;
padding:10px;
line-height:16px;
background:transparent;
border:0px solid #555;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.1s;
}
.lang:active{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.right{float:right;}
table{width:100%;}
td{padding:2px;margin:0;}
</style>
<title><?php echo $lang[48];?></title>
<div align="center">
<div class="main">
<table frame="void" border-rules="none" cellspacing="0" align="center">
<tr>
<td><div class="lang"><?php echo $lang[47];?><b class="right"><?php echo $lang[46];?></b></div></td>
</tr>
<tr>
<td><a href="?!=lang-uage&lang=cn" target="iframe"><div class="lang">简体中文</div></a></td>
</tr>
<tr>
<td><a href="?!=lang-uage&lang=en" target="iframe"><div class="lang">English</div></a></td>
</tr>
</table>
</div></div>
<?php ;exit;}}?>




<?php
if($get=="index"){
if(!$_SESSION['weofficekey'] && !$_SESSION['wenamesandin'] && !$_SESSION['weofficeserm'] && !$_SESSION['weallnameorkey']){echo "<script>location='?!=login'</script>";}else if(!$_SESSION['weofficekey'] or !$_SESSION['wenamesandin'] or !$_SESSION['weofficeserm'] or !$_SESSION['weallnameorkey']){echo "<script>location='?!=logout'</script>";}
$names=$_SESSION['weallnameorkey'];
$userth="$udir/$names.tdr.php";
if(file_exists($userth)){require "$udir/$names.tdr.php";}else{echo "<script>location='?!=logout'</script>";exit;}
?>





<html onselectstart="return false">
<title><?php echo $lang[1];?></title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<body>
<style>
*{line-height:16px;font-size:14px;}
body{
margin:0;
}
#ok{
margin:0;
width:100%;
height:100%;
overflow:hidden;
position: fixed;
-webkit-text-size-adjust: none;
<?php if($ofbg=="off" or $ofbg==""){?>
background: url("?!=bg") no-repeat fixed center;
background-size: cover;
background-origin:border-box;
<?php }?>
-webkit-tap-highlight-color: rgba(255, 255, 255, 0);
z-index:1;
}
<?php if($ofbg=="on"){?>
#ok::after{
content: '';
margin:-30px;
position: fixed;
background: url("?!=bg") no-repeat fixed center;
background-size: cover;
background-origin:border-box;
-webkit-filter: blur(20px);
-moz-filter: blur(20px);
-ms-filter: blur(20px);
-o-filter: blur(20px);
filter: blur(20px);
zoom:1;
top: 0;
left: 0;
right: 0;
bottom: 0;
z-index: -1;
}
<?php }?>
.mu{
max-width:500px;
text-align:left;
padding:10px;
border-radius:5px;
margin:10px;
/*backdrop-filter: blur(10px);*/
box-shadow:0 0 1px 0 rgba(0,0,0,.5);
background:rgba(255,255,255,.5);
}
.dtd{
padding:10px;
border-radius:5px;
background:tranparent;
box-shadow:0 0 1px 0 rgba(0,0,0,.2);
transition:box-shadow 0.1s;
}
.dtd:active{
box-shadow:0 0 5px 0 rgba(0,0,0,.2);
}
.right{float:right;}
table{width:100%;}
td{padding:2px;margin:0;}
</style>
<div id="ok">
<svg width="20" height="20" viewBox="0 0 250 250" style="fill: #666;color: #fff;position: absolute;top: 0;border: 0;right: 0;"></svg>
<div align="center">
<div class="mu"><?php echo $lang[23];?>: <?php echo $un?><a onclick="return confirm('<?php echo $lang[34];?>','<?php echo $lang[44];?>,<?php echo $lang[45];?>')" href="?!=logout" target="iframe" style="float:right"><?php echo $lang[35];?></a></div>
<?php if($language=="cn"){ if(file_exists($saying)){?><div class="mu">
<div style="line-height:20px;"><?php echo $two;?></div>
</div>
<?php }};?>
<div class="mu">
<table frame="void" border-rules="none" cellspacing="0" align="center">
<tr>
<td><div class="dtd"><?php echo $lang[56];?></div></td>
</tr>
</table>
</div>
<div class="mu">
<div><?php echo $lang[36];?></div>
</div>
<div class="mu">
<table frame="void" border-rules="none" cellspacing="0" align="center">
<tr>
<td><a href="?!=ofbg" target="iframe"><div class="dtd"><?php echo $lang[37];?><b class="right"><?php if($ofbg=="on"){echo "$lang[38]";}else{echo "$lang[39]";}?></b></div></a></td>
</tr>
<tr>
<td><a href="?!=repw"><div class="dtd"><?php echo $lang[40];?><b class="right">＞</b></div></a></td>
</tr>
<tr>
<td><a href="?!=feedback"><div class="dtd"><?php echo $lang[41];?><b class="right">＞</b></div></a></td>
</tr>
<tr>
<td><a href="?!=lang"><div class="dtd"><?php echo $lang[42];?><b class="right">＞</b></div></a></td>
</tr>
</table>
</div>
<div class="mu">
<div><?php echo $lang[43];?></div>
</div>
<div class="mu">
<div>2022-<?php echo $year." ";?><?php if($language=="en"){echo pack("C*",70,114,111,109,32,84,100,114,115,101);/*From Tdrse*/}else{echo pack("C*",230,157,165,232,135,170,84,68,82,83,69);}?></div>
</div>


</div>
</div>







<?php };?>





</div>
</body>
</html>
