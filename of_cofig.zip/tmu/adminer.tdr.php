<?php 
$un='adminer';
$pw='1e5334caed399aed8b9abba51ee8bb94';
$thesm='5315154b45b1ea362693dc9acf846694';
?>