<?php 
$un='tdrsem';
$pw='79ff02c9c3ddbd7a8d681b123484a15f';
$thesm='d244aad77d271e2e0f19fce50a825bb4';
?>