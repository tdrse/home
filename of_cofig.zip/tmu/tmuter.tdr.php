<?php 
$un='tmuter';
$pw='48c2d89d8052a29bf129a6445e9a4c16';
$thesm='4db360da158896496146e561991f872f';
?>