<?php
/*
author:tdrse
e-mail:tdrse@outlook.com
version:1.7
*/
$keys=$_GET['w'];
$word='./wd.php';
if(@file_exists($word)){
header('Content-type: text/html; charset=utf-8');

$data=@file_get_contents($word);
$well=explode("###\n", $data);

function filter($v)
{
$keys=$_GET['w'];
$my=@substr($v,0,@stripos($v,"\n"));
if (strtolower(preg_replace("/\\d+/",'', $my))===strtolower($keys))
{return true;}return false;}
$holl=array_filter($well,"filter");
$result=nl2br($well[array_rand($well)]);
$one=str_replace('*/?>','',str_replace('<?php /*','',$result));
//$two=str_replace(array("\r","\n","\r\n"),'',$one);
}

?>
<!DOCTYPE html>
<html onselectstart="return false" oncontextmenu="window.event.returnValue=false">
<head>
<meta charset="utf-8" name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no,target-densitydpi=device-dpi">
<title>TRA - <?php if($keys){echo "Search - $keys";}else{echo "Author:tdrse - Index";}?></title>
</head>
<body>
<style>
@font-face{
font-family: ct;
src: url('ct.woff2');
}
*{
font-family:ct;
outline:none;
color:#333;
line-height:24px;
box-sizing:border-box;
/*vertical-align:middle;*/
word-spacing:normal;
-webkit-text-size-adjust: none;
-webkit-tap-highlight-color: rgba(0,0,0,0);
-moz-user-select:none;
-webkit-user-select:none;
-ms-user-select:none;
-khtml-user-select:none;
-o-user-select:none;
user-select:none;
transition:all 0.2s;
}
a{
text-decoration:none;
}
img{
width:100%;
pointer-events:none;
border-radius:2px;
}
body{
margin:0;
width:100%;
background:#f5f5f5;
}
#cb{
max-width:600px;
padding:0px 5px 0px 5px;
}
#gl{
max-width:600px;
text-align:left;
padding:0px;
}
#gl div{
background:#fff;
border:0px solid #f5f5f5;
border-radius:2px;
padding:10px;
margin:5px 0px 5px 0;
box-shadow:0 1px 3px 0 rgba(120,120,120,.5);
}
#sh{
padding:5px 10px 5px 10px;
width:100%;
border:1px solid #f5f5f5;
background:#f7f7f7;
border-radius:2px;
}
#fx{
border:0px solid #000;
display:flex;
max-width:600px;
text-align:left;
}
#fx div{
flex:1;
background:#fff;
border:0px solid #f5f5f5;
border-radius:2px;
padding:10px;
box-shadow:0 1px 3px 0 rgba(120,120,120,.5);
}
#gx{
margin:0 2.5px 5px 5px;
}
#ab{
margin:0 5px 5px 2.5px;
}
#dc{
display:flex;
font-size:24px;
}
#dc a{
flex:1;
}
</style>
<script>
function to(){
document.onkeydown=function(ev){
var event=ev || event;
if(event.keyCode==13){
location='?w=' + document.getElementById("sh").value;
}
}
}
</script>
<center>
<div id="cb">
<div id="gl">
<div>
<input type="text" id="sh" placeholder="搜~" onkeydown="to()">
</div>
</div>
<?php if($keys){
if($holl){
echo "<div id=\"gl\"><div id=\"dc\"><abbr id=\"kp\">" . preg_replace("/\\d+/",'',stristr(nl2br(implode('</div></div><div id="gl"><div>',$holl)),"\n",TRUE)) . "</abbr><a></a><b id=\"cl\">★/☆</b></div></div>";
echo "<div id=\"gl\"><div>" . nl2br(implode('</div></div><div id="gl"><div>',$holl)) . "</div></div>";
}else{
echo "<div id=\"gl\"><div>未找到此单词~</div></div>";
}
}else{echo "<div id=\"gl\"><div id=\"dc\"><abbr id=\"kp\">" . preg_replace("/\\d+/",'',stristr($one,"\n",TRUE)) . "</abbr><a></a><b>★/☆</b></div></div>";echo "<div id=\"gl\"><div>" . $one . "</div></div>";}


?>
<?php if(!$keys){?>
<div id="gl">
<div onclick="location='';">下一个</div>
</div>
<?php };?>
</div>
<div id="fx">
<div id="gx" onclick="location='?w=关于';">关于</div>
<div id="ab" onclick="location='?w=说明';">帮助</div>
</div>
</center>
</body>
</html>


